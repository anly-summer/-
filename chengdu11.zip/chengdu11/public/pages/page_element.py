#coding=utf-8
'''
此模块用来装页面的元素定位的文本

'''''

class  Page_elem(object):
    #1.登录账号元素
    userName = ["id", "userAccount"]
    #2.登录密码元素
    passwd = ["id", "loginPwd"]
    #3.登录按钮元素
    loginbtn = ["id", "loginBtn"]


p=Page_elem()


















